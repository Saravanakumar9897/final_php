<?php
/**
* @Author:Banupriya
* @Description:This Autoload class will dynamically load the required files in required place.
*/
namespace Autoloader;

class Autoload
{
    //This load function will store all the php files in the name of models then helpers folder having the connection folder is named as connection,then the classes folder is named as Classes,likewise the following folders respectively.
    public static function load($dir){
        $NameSpaces = [
            "Models\\" => "Models",
            "Connection\\" => "Helpers/Connection",
            "Classes\\" => "Helpers/Classes",
            "Request\\" => "Helpers/Request",
            "Sessions\\" => "Helpers/Sessions",
            "Controllers\\" => ["Controllers"]
        ];
        foreach ($NameSpaces as $namespace => $classpaths) {
            if (!is_array($classpaths)) {
                $classpaths = array($classpaths);
            }
            //If the containing file has class inside the file then this spl_autoload_register function is executed based on their file name.

            spl_autoload_register(function ($classname) use ($namespace, $classpaths, $dir) {
                if (preg_match("#^".preg_quote($namespace)."#", $classname)) {
                    $classname = str_replace($namespace, "", $classname);
                    $filename = preg_replace("#\\\\#", "/", $classname).".php";
                    foreach ($classpaths as $classpath) {
                        $fullpath = $dir."/".$classpath."/$filename";
                        if (file_exists($fullpath)) {
                            include_once $fullpath;
                        }
                    }
                }
            });
        }
        //Else the containing file doesn't have any class inside the file,then the below line will be executed. 
        $Files = [
            "Config/config.php",
            "Helpers/Functions/AppFunctions.php",
        ];
        foreach($Files as $file){
            $fullpath = $dir."/".$file;
            if(file_exists($fullpath)){
                include_once($fullpath);
            }
        }
    }
}

Autoload::load(str_replace('/Helpers/Autoload','',str_replace('\\','/',__DIR__)));
