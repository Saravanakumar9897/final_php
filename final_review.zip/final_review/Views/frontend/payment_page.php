<!doctype html>
<html lang="en">
<head>
<?php view('frontend/partial/head_links.php') ?>
<?php $movieOfScreen = import();
    $year = date('Y');
    $month = date('m');
    $date = date('d');
    $max_date = $date + 4;
    $movie_id = $_REQUEST['movie_id'];
    $theatre_id = $_REQUEST['theatre_id'];
    foreach ($movieOfScreen as $key => $value) {
    if($movieOfScreen[$key]['movie_id']==$movie_id){
        $movie_data[]=$movieOfScreen[$key];
    }

    }
    $movie=$movie_data[$theatre_id];
?>
</head>
<body style="background: transparent;">
<?php view('frontend/partial/header.php') ?>
<main>
    <div id="demo" class="carousel slide card" data-ride="carousel">
        <!-- Indicators -->
        
        <!-- The slideshow -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="#">
                    <img src="<?php echo $movie['list_image'] ?>" alt="Los Angeles" width="1100" height="500">
                </a>
            </div>
        </div>
        <!-- Left and right controls -->
        
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center" style="margin-top: -100px">
                    <div class="card card-inverse card-info">
                        <img class="card-img-top" src="<?php echo $movie['banner_image'] ?>" style="padding: 5px" height="350">
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div class="card-header">
                                <i class="fa fa-angle-down pull-left" data-toggle="collapse" data-target="#language_demo"></i>
                                <b>APPLICABLE OFFERS</b>
                            </div>
                            <div id="language_demo" class="card-body text-left collapse show">
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/amazon-pay-cashback-offer-amazonpaycashback.jpg?23102019181006" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>Amazon Pay cashback offer</b><br>
                                        <span class="offer-text">Win Cashback Upto Rs 500*</span>
                                    </div>
                                </div>
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/paypal-cashback-offer-paypalcashback.jpg?31102019102826" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>PayPal Offer</b><br>
                                        <span class="offer-text">Transact first time with Paypal and get 100% cashback up to Rs. 500</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 border">
                    <div id="dynamic_redirection"><br>
                    <div>
                        <span class="details_remainder" id="movieName"><?php echo $movie['name']; ?></span>
                        <a href="/" class="change_details"><i class="fa fa-close fa-xs"></i></a>
                        <span class="details_remainder" id="movieName"><?php echo $movie['theatre_name'].'-'.$movie['show_name']; ?></span>
                        <a href="/" class="change_details"><i class="fa fa-close fa-xs"></i></a>
                    </div><br>
                    <div class="row form-group">
                        <div class="col-md-12 form-group">
                            <div class="card" style="height: 100%; width:100%;">
                                <div class="card-header">Verify Your Booking details:</div>
                                    <div class="card-body">     
                                    <!-- form container start -->
                                        <form>
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <td class="text-center">Name of the User</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="userName">Saravana Kumar</span></td>
                                            </tr>
                                            <tr>
                                                <td class="text-center">Movie Name</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="movieName"><?php echo $movie['name']; ?></span></td>
                                            </tr>
                                            <tr>
                                                <td class="text-center">Seat Class</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="classType">First Class</span></td>
                                            </tr>
                                            <tr>
                                                <td class="text-center">Seat Numbers</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="seatNumbers">F1,F2,F3,F4</span></td>
                                            </tr>
                                            <tr>
                                                <td class="text-center">No.of Seats</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="seatCount">4</span></td>
                                            </tr>
                                            <tr>
                                                <td class="text-center">Total Amount</td>
                                                <td class="text-left">:</td>
                                                <td class="text-left"><span id="amount">400</span></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-right"><input id="submit" class="btn btn-info" type="button" value="Process" onclick="paymentRedirect();" name="paymentSubmit"></td>
                                            </tr>
                                        </table>
                                        </form>
                                    <!-- form container end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 form-group" id="seat_count">   </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="<?php echo asset('backend/js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/popper.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/main.js') ?>"></script>
<script src="<?php echo asset('frontend/js/main.js') ?>"></script>

<script type="text/javascript">
// #javascript.function(select box selected) end
    var movie_name = localStorage.getItem('movie_name');
    var total_seat = localStorage.getItem('totalSeats');
    var movieId = localStorage.getItem('movieId');
    var booking_date = localStorage.getItem('date');
    var booking_amount = localStorage.getItem('total_amount');
    var seat_class = localStorage.getItem('seat_class');
    var seat_string = localStorage.getItem('select_seats');
    var select_seats = seat_string.split(",");

    document.getElementById("movieName").innerHTML = movie_name;
    document.getElementById("seatNumbers").innerHTML = select_seats;
    document.getElementById("classType").innerHTML = seat_class;
    document.getElementById("seatCount").innerHTML = select_seats.length;
    document.getElementById("amount").innerHTML = booking_amount;


    function cardHolderCheck(){
        _cardHolder = document.getElementById("cardHolder").value;
        if(_cardHolder.charCodeAt(0)<65 || _cardHolder.charCodeAt(0)>90){
            document.getElementById("cardHolderCheck").innerHTML = "First Must be in capital";
        }else{
            document.getElementById("cardHolderCheck").innerHTML = "";
            var splitString = _cardHolder.split("");
            var reverseArray = splitString.reverse();
            var joinArray = reverseArray.join("");
            var regex=/^[a-zA-Z]+$/;
            if (!joinArray[0].match(regex))
            {
                document.getElementById("cardHolderCheck").innerHTML = "Enter Characters Only";
            }
        }
    }

    function cardNumberCheck(){
        _cardNumber = document.getElementById("cardNumber").value;
        if(_cardNumber.length!=0){
            if(_cardNumber.length<=16){
                if(_cardNumber.length!=0){
                var splitString = _cardNumber.split("");
                var reverseArray = splitString.reverse();
                var joinArray = reverseArray.join("");
                var regex=/^[a-zA-Z]+$/;
                if (joinArray[0].match(regex))
                {
                    document.getElementById("cardNumberCheck").innerHTML = "Enter Numbers Only";
                }
                }else{
                    document.getElementById("cardNumberCheck").innerHTML = "";
                }
            }else{
                document.getElementById("cardNumberCheck").innerHTML = "Enter 16 Numbers Only";
            }
        }else{
            document.getElementById("cardNumberCheck").innerHTML = "";
        }
    }

    function finalValidate(){
        _cardNumber = document.getElementById("cardNumber").value;
        _cardHolder = document.getElementById("cardHolder").value;
        _ExpiryMonth = document.getElementById("ExpiryMonth").value;
        _ExpiryYear = document.getElementById("ExpiryYear").value;
        _Cvv = document.getElementById("Cvv").value;
        if(_cardNumber.length==16 &&(_cardHolder.charCodeAt(0)>65 || _cardHolder.charCodeAt(0)<90)){
            if ((!_cardNumber.match(regex)) && (_cardHolder.match(regex))){
                return true;
            }else{
                document.getElementById("formCheck").innerHTML = "Check Card Number and User Name";
                return false;
            }
        }else{
            document.getElementById("formCheck").innerHTML = "Enter 16 Numbers in Card Number and First letter Must be Capital";
            return false;
        }
    }

    function paymentRedirect(){
        var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        var text = this.responseText;
                        document.getElementById('dynamic_redirection').innerHTML = text;
                    }
                };
            xhttp.open("get","/payment?movie_id="+<?php echo $movie['movie_id'] ?>+"&amount="+booking_amount+'&count='+select_seats.length+'&class='+seat_class+'&class_type='+seat_class+'&seat_no='+select_seats+'&theatre_id='+<?php echo $theatre_id ?>,true);
            xhttp.send();
    }

    // function paymentSubmission(){
    //     location.href=('/payment_submit?movie_of_screen_id='+movieId+'&movieName='+movie_name+'&seatNumbers='+select_seats+'&seatCount='+select_seats.length+'&amount='+booking_amount,true);
    // }

    function seat_selection_page(){
        location.href=('/select_seats?movie_of_screen_id='+movieId);
    }
    // $("#detail_catcher").load(function(){
    //         document.getElementById("movieName").innerHTML = movie_name;
    //         document.getElementById("seatNumbers").innerHTML = select_seats;
    //         document.getElementById("pay_seatCount").innerHTML = select_seats.length;
    //         document.getElementById("pay_amount").innerHTML = booking_amount;
    // });
// #javascript.function(select box selected) end
</script>
</body>
</html> 