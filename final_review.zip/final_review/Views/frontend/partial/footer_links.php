<footer class="footer">
  <div class="container" style="text-align: center;">
    
    	<!-- Add font awesome icons -->
		<a href="https://www.facebook.com" class="fa fa-facebook"></a>
		<a href="https://www.twitter.com" class="fa fa-twitter"></a>
		<a href="https://www.google.com" class="fa fa-google"></a>
		<a href="https://www.linkedin.com" class="fa fa-linkedin"></a>
		<a href="https://www.youtube.com" class="fa fa-youtube"></a>
		<a href="https://www.instagram.com" class="fa fa-instagram"></a>
    
  </div>
</footer>