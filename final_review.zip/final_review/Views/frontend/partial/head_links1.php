<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Movie Ticket Booking</title>
<!-- Main CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo asset('backend/css/main.css') ?>">
<link rel="stylesheet" type="text/css" href="<?php echo asset('frontend/css/main.css') ?>">
<!-- Font-icon css-->
<link rel="stylesheet" type="text/css" href="<?php echo asset('frontend/css/font-awesome.min.css')?>">
<link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Anton&display=swap" rel="stylesheet"> 