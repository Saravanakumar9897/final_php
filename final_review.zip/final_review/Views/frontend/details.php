<!doctype html>
<html lang="en">
<head>
<?php view('frontend/partial/head_links.php') ?>
<?php include('details_data.php'); ?>
</head>
<body style="background: transparent;">
<?php view('frontend/partial/header.php') ?>
<main>
    <div id="demo" class="carousel slide card" data-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="#">
                    <img src="<?php echo $movie_data[0]['list_image'] ?>" alt="Los Angeles" width="1100" height="500">
                </a>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center" style="margin-top: -100px">
                    <div class="card card-inverse card-info">
                        <img class="card-img-top" src="<?php echo $movie_data[0]['banner_image'] ?>" style="padding: 5px" height="350px">
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div id="language_demo" class="card-body text-left collapse show">
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/amazon-pay-cashback-offer-amazonpaycashback.jpg?23102019181006" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>Amazon Pay cashback offer</b><br>
                                        <span class="offer-text">Win Cashback Upto Rs 500*</span>
                                    </div>
                                </div>
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/paypal-cashback-offer-paypalcashback.jpg?31102019102826" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>PayPal Offer</b><br>
                                        <span class="offer-text">Transact first time with Paypal and get 100% cashback up to Rs. 500</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 border"><br>
                    <div>
                        <span class="details_remainder" id="movieName"><?php echo $movie_data[0][0] ; ?></span>
                        <a href="/" class="change_details"><i class="fa fa-close fa-xs"></i></a>
                    </div><br>
                    <div class="row form-group">
                        <div class="col-md-4 form-group">
                            <div class="card" style="height: 100%">
                                <div class="card-header">Movie Details</div>
                                <div class="card-body">
                                    <table class="table table-sm table-borderless">
                                        <tr>
                                            <td>Movie</td>
                                            <td>:</td>
                                            <td><span id="movie_name"><?php echo $movie_data[0]['name'] ?></span></td>
                                        </tr>
                                        <tr>
                                            <td>Duration</td>
                                            <td>:</td>
                                            <td><?php echo $movie_data[0]['duration'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Actor</td>
                                            <td>:</td>
                                            <td><?php echo $movie_data[0]['actor']  ?></td>
                                        </tr>
                                        <tr>
                                            <td>Actress</td>
                                            <td>:</td>
                                            <td><?php echo $movie_data[0]['actress']  ?></td>
                                        </tr>
                                        <tr>
                                            <td>Director</td>
                                            <td>:</td>
                                            <td><?php echo $movie_data[0]['director'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Producer</td>
                                            <td>:</td>
                                            <td><?php echo $movie_data[0]['producer']  ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 form-group">
                            <div class="card" style="height: 100%">
                                <div class="card-header">
                                    <span class="card-header">
                                        Movie Description
                                    </span>
                                    <span class="card-header text-center">
                                        <a href="<?php echo baseURL().'/select_show?'.strtolower($movie_data[0]['name']);?>" class="btn btn-info btn-lg">Book Tickets</a>
                                    </span>
                                </div>
                                <div class="card-body">
                                    <?php echo html_entity_decode($movie_data[0]['description'])?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <div id="demo" class="carousel slide card" data-ride="carousel">
                                <!-- Indicators -->
                                <ul class="carousel-indicators">
                                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                                    <li data-target="#demo" data-slide-to="1"></li>
                                    <li data-target="#demo" data-slide-to="3"></li>
                                </ul>
                                <!-- The slideshow -->
                                <div class="carousel-inner"> 
                                    <div class="carousel-item active">                                  
                                        <div class="col-md-3">
                                            <a href="#">
                                                <img src="<?php echo $movie_data[0]['list_image']  ?>" alt="Los Angeles">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Left and right controls -->
                                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                    <span class="carousel-control-prev-icon"></span>
                                </a>
                                <a class="carousel-control-next" href="#demo" data-slide="next">
                                    <span class="carousel-control-next-icon"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">Book your ticket enjoy that day!</div>
                                <div class="card-header text-center">
                                    <a href="<?php echo baseURL().'/select_show?'.strtolower($movie_data[0]['name']);?>" class="btn btn-info btn-lg">Book Tickets</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="<?php echo asset('backend/js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/popper.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/main.js') ?>"></script>
<script src="<?php echo asset('frontend/js/main.js') ?>"></script>
<script type="text/javascript">
    var uri = window.location.search;
    var id = uri.split("=");id = id[1];
    localStorage.setItem('movieId', id);
    var movie_name = document.getElementById('movie_name').innerHTML;
    localStorage.setItem('movie_name', movie_name);
</script>
</body>
</html>