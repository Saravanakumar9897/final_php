<!doctype html>
<html lang="en">
<head>
<?php view('frontend/partial/head_links.php') ?>
<?php include('select_show_data.php')?>
<?php
    $year = date('Y');
    $month = date('m');
    $date = date('d');
    $max_date = $date + 4;
?>
</head>
<body style="background: transparent;">
<?php view('frontend/partial/header.php') ?>
<main>
    <div id="demo" class="carousel slide card" data-ride="carousel">
        <!-- Indicators -->
        
        <!-- The slideshow -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="#">
                    <img src="<?php echo $movieOfScreen[0]['list_image'] ?>" alt="Los Angeles" width="1100" height="500">
                </a>
            </div>
        </div>
        <!-- Left and right controls -->
        
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center" style="margin-top: -100px">
                    <div class="card card-inverse card-info">
                        <img class="card-img-top" src="<?php echo $movieOfScreen[0]['banner_image'] ?>" style="padding: 5px" height="350">
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div class="card-header">
                                <i class="fa fa-angle-down pull-left" data-toggle="collapse" data-target="#language_demo"></i>
                                <b>APPLICABLE OFFERS</b>
                            </div>
                            <div id="language_demo" class="card-body text-left collapse show">
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/amazon-pay-cashback-offer-amazonpaycashback.jpg?23102019181006" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>Amazon Pay cashback offer</b><br>
                                        <span class="offer-text">Win Cashback Upto Rs 500*</span>
                                    </div>
                                </div>
                                <div class="row border-dotted">
                                    <div class="col-md-2">
                                        <img height="30" width="30" src="https://in.bmscdn.com/offers/offerlogo/paypal-cashback-offer-paypalcashback.jpg?31102019102826" alt="">
                                    </div>
                                    <div class="col-md-10">
                                        <b>PayPal Offer</b><br>
                                        <span class="offer-text">Transact first time with Paypal and get 100% cashback up to Rs. 500</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 border"><br>
                    <div class="row form-group">
                <div class="col-md-12 border"><br>
                    <div class="row form-group">
                        <div class="col-md-12 form-group">
                            <div class="card" style="height: 100%; width:100%;">
                                <div class="card-header">Movie Details</div>
                                <div class="card-body">
                                    <table class="table table-sm table-borderless">
                                        <tr>
                                            <td>Movie : <span id="movie_name"><?php echo $movieOfScreen[0]['name']?></span></td>
                                            <td>Duration : <span id="movie_name"><?php echo $movieOfScreen[0]['duration'] ?></span></td>
                                            <td>Actor : <span id="movie_name"><?php echo $movieOfScreen[0]['actor'] ?></span></td>
                                        </tr>
                                        <tr>
                                            <td>Actress : <span id="movie_name"><?php echo $movieOfScreen[0]['actress'] ?></span></td>
                                            <td>Director : <span id="movie_name"><?php echo $movieOfScreen[0]['director'] ?></span></td>
                                            <td>Producer : <span id="movie_name"><?php echo $movieOfScreen[0]['producer'] ?></span></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <div class="card" style="height: 100%; width:100%;">
                                <div class="card-header">Movie Details</div>
                                <div class="card-body">
                                    <table class="table table-sm table-borderless">
                                        <tr>
                                            <td>Select Date</td>
                                            <td>:</td>
                                            <td>
                                                <input class="btn btn-info" id="date" type="date" name="date" min="<?php echo $year.'-'.$month.'-'.$date; ?>" max="<?php echo $year.'-'.$month.'-'.$max_date; ?>">
                                            </td>
                                        </tr>
                                        
                                            <?php foreach ($movieOfScreen as $key => $value) {?>
                                            <tr>
                                            <td><?php echo $movieOfScreen[$key]['theatre_name'] ?></td>
                                            <td>:</td>
                                            <td><button id="<?php echo $key; ?>" class="btn btn-md btn-info" onclick="seat_count(this.id)"><?php echo $movieOfScreen[$key]['show_name']?></button></td>
                                            </tr>
                                            <?php } ?>                               
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 form-group" id="seat_count"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="<?php echo asset('backend/js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/popper.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/main.js') ?>"></script>
<script src="<?php echo asset('frontend/js/main.js') ?>"></script>

<script type="text/javascript">
// #javascript.function(select box selected) end
    var movie_name = localStorage.getItem('movie_name');
    var movie_id = localStorage.getItem('movieId');
    
    function seat_count(theatreId){

        var xhttp = new XMLHttpRequest();
        var date = document.getElementById('date').value;
        if(date != ''){
            localStorage.setItem('date', date);
            var theatre_id =  theatreId;
            localStorage.setItem('theatreId',theatre_id);
                xhttp.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        var text = this.responseText;
                        document.getElementById('seat_count').innerHTML = text;
                    }
                };
            xhttp.open("get","/seat_count",true);
            xhttp.send();
        }else{
            alert('please select date');
        }
    }
// #javascript.function(select box selected) This below function using to storing the number of seats selected by the user in the input storage by using localStorage.settime;
    function seatview(numbers) { 
        total_seats = numbers;
        localStorage.setItem('totalSeats', total_seats);
    //storing into the as internal storsge file
    }

    function nextPage(){  
        var theatre_id = localStorage.getItem('theatreId');
        if(total_seats != ''){ 
            location.href=('/select_seats?movie_of_screen_id='+<?php echo $movieOfScreen[0]['movie_id']; ?>+'&theatre_id='+theatre_id);
        }
    }
// #javascript.function(select box selected) end
</script>
</body>
</html> 