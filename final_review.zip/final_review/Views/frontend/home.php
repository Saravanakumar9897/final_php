<!-- Author     : Saravanakumar.N<saravanakumar@infinitisoftware.net>
     Description: The Dashboard for the User Interface for the End user. 
 -->

<!doctype html>
<html lang="en">
<head>
<?php view('frontend/partial/head_links.php') ?>
<?php $mve = import();?>
<?php $movies = array_reverse($mve); ?>


</head>
<body class="container-fluid" style="background: transparent;">
<?php view('frontend/partial/header.php') ?>
<main class="container-fluid">
    <div id="demo" class="carousel slide card" data-ride="carousel">
        <!-- Indicators -->
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
        </ul>
        <!-- The slideshow -->
        <div class="carousel-inner">
                    <!-- carousel starts -->
                    <div class="carousel-item active">
                        <a href="/details?<?php echo strtolower($movies[14][2]) ?>">
                            <img class="img-responsive" src="<?php echo $movies[14][11] ?>" alt="Los Angeles" width="1100" height="500">
                        </a>
                    </div>
               
                    <div class="carousel-item ">
                        <a href="/details?<?php echo strtolower($movies[7][2]) ?>">
                            <img src="<?php echo $movies[7][11] ?>" alt="Los Angeles" width="1100" height="500">
                        </a>
                    </div>
           <!-- carousel ends -->
        </div>
        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
    <div class="card">
        <div class="card-header">
            <a href=" "><strong class="" style="font-size: 24px; color:black;">Movies</strong></a>
            <a href="#" id="ns" onclick="changeActiveNS()" class="btn btn-primary btn-md">Now Showing</a>
            <a href="#" id="cs" onclick="changeActiveCS()" class="btn btn-primary btn-md">Comming Soon</a>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center">
                    <div class="card card-inverse card-info">
                        <img class="card-img-top" src="https://picsum.photos/200/150/?random" style="padding: 10px" height="300px">
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div class="card-header">
                                <i class="fa fa-angle-down pull-left" data-toggle="collapse" data-target="#language_demo"></i>
                                Language
                            </div>
                            <div id="language_demo" class="card-body text-left collapse show">
                                <input type="checkbox"> Hindi <br>
                                <input type="checkbox"> English <br>
                                <input type="checkbox"> Marathi <br>
                                <input type="checkbox"> Gujarati <br>
                                <input type="checkbox"> Telugu <br>
                                <input type="checkbox"> Tamil <br>
                                <input type="checkbox"> Malayalam <br>
                                <input type="checkbox"> Punjabi <br>
                                <input type="checkbox"> Bhojpuri <br>
                            </div>
                        </div>
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div class="card-header">
                                <i class="fa fa-angle-down pull-left" data-toggle="collapse" data-target="#Genre_demo"></i>
                                Categories
                            </div>
                            <div id="Genre_demo" class="card-body text-left collapse">
                               
                                    <input type="checkbox"><br>
                              
                            </div>
                        </div>
                    </div>
                    <div class="card card-inverse card-info">
                        <div class="card-block">
                            <div class="card-header">
                                <i class="fa fa-angle-down pull-left" data-toggle="collapse" data-target="#Format_demo"></i>
                                    Format
                            </div>
                            <div id="Format_demo" class="card-body text-left collapse">
                                <input type="checkbox"> 2D <br>
                                <input type="checkbox"> 3D <br>
                                <input type="checkbox"> 3D SCREEN X <br>
                                <input type="checkbox"> 4DX <br>
                                <input type="checkbox"> 4DX 3D <br>
                                <input type="checkbox"> MX4D <br>
                                <input type="checkbox"> IMAX 2D <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <div id="mrn" class="row">
                        <?php foreach ($movies as $key => $value) { ?>
                            
                            <div class="col-md-4 text-center">
                                <div class="card card-inverse card-info">
                                    <a href="/details?<?php echo strtolower($movies[$key][2]) ?>">
                                        <img alt="Movie-card" id="movie_id" class="card-img-top img-responsive" src="<?php echo $movies[$key][10]?>" height="320px">
                                    </a>
                                    <div class="card-block">
                                        <div class="card-text">
                                            Director: <?php echo ucfirst(strtolower($movies[$key][7])) ?>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <a href="/details?<?php echo strtolower($movies[$key][2]) ?>">
                                        <small class="btn btn-md btn-success float-left"><?php echo $movies[$key][2] ?></small>
                                        <button class="btn btn-md btn-info float-right"><i class="fa fa-heart"><?php echo $movies[$key]['rating'] ?></i></button>
                                        </a>
                                    </div>

                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="<?php echo asset('backend/js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/popper.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo asset('backend/js/main.js') ?>"></script>
<script src="<?php echo asset('frontend/js/main.js') ?>"></script>
<script>
    function changeActiveNS(){
            document.getElementById('ns').classList.add('btn-success');
            document.getElementById('cs').classList.remove('btn-success');
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    var a = this.responseText;
                    console.log(a);
                    document.getElementById('mrn').innerHTML=a;

                }
            };
            xhttp.open("get","/now_showing",true);
            xhttp.send();
    }
    function changeActiveCS(){
            document.getElementById('ns').classList.remove('btn-success');
            document.getElementById('cs').classList.add('btn-success');
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    var a = this.responseText;
                    console.log(a);
                    document.getElementById('mrn').innerHTML=a;

                }
            };
            xhttp.open("get","/coming_soon",true);
            xhttp.send();
    }
</script>
</body>
</html>