<!DOCTYPE html>
<html>
<head>
    <title>Ticket Details</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/backend/css/bootstrap.min.css">
    <?php $ticket_details = import(); ?>
    <?php view('frontend/partial/head_links.php') ?>
</head>
<body>
<?php view('frontend/partial/header.php') ?>
    <div id="ticket_preview" class="text-center">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <table id="dataCheck" class="table table-default">
                    <tr class="text-center">
                        <th></th>
                        <th class="text-center">Ticket Preview</th>
                        <th></th>
                    </tr>
                    <tr>
                        <td class="text-right">User Name</td>
                        <td class="text-center">:</td>
                        <td><?php echo $_SESSION['CurrentUserData']['name']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Movie Name</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['name']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Theatre Name</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['theatre_name']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Screen Name</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['screen_name']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Show Name</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['show_name']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Booking Class</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['seat_class']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Seat Numbers</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['seat_number']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Total Seats</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['total_seats']; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">Total Amount</td>
                        <td class="text-center">:</td>
                        <td><?php echo $ticket_details['total_amount']; ?></td>
                    </tr>
                    <tr>
                            
                    </tr>
                </table>
            </div>
        </div><br>
            <a href="<?php echo baseURL().'/'.strtolower($movie_data[0]['name']);?>"><button class="btn btn-danger btn-lg">Go Home</button></a><br><br>
    </div>
</body>
</html>