<?php $movies = import();?>
 <?php foreach ($movies as $key => $value) { ?>
                            
      <div class="col-md-4 text-center">
        <div class="card card-inverse card-info">
           <a href="/details?<?php echo strtolower($movies[$key][2]) ?>">
               <img alt="Movie-card" id="movie_id" class="card-img-top mg-responsive" src="<?php echo $movies[$key][10]?>" height="320px">
            </a>
            <div class="card-block">
                <div class="card-text">
                   Director: <?php echo $movies[$key][7] ?>
                </div>
            </div>
            <div class="card-footer">
              <a href="/details?<?php echo strtolower($movies[$key][2]) ?>">
              <small class="btn btn-md btn-success float-left"><?php echo $movies[$key][2] ?></small>
               <button class="btn btn-md btn-info float-right"><i class="fa fa-heart"><?php echo $movies[$key]['rating'] ?></i></button>
             </a>
            </div>
        </div>
    </div>
<?php } ?>