<?php
/**
 * User: Vishnu Vardhan G
 * Date: 14/11/19
 * Time: 15:58 AM
 */
namespace models;

use Connection\DB;
use PDO;
use Throwable;

class paymentAndBooking 
{
    public static function payment($user_data){
        try{
            $sql = "INSERT INTO t_payments (r_user_id,total_amount) VALUES (:user_id,:amount)";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([
                ':user_id'=> $_SESSION['CurrentUserData']['user_id'],
                ':amount' => $_SESSION['amount']
            ]);

            $sql = "SELECT * FROM t_payments ORDER BY payment_id DESC limit 1";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute();
            $payments_data = $stmt->fetch(PDO::FETCH_ASSOC);


            $sql = "SELECT * FROM t_movie_of_screens WHERE r_movie_id = :movie_id 
                    ORDER BY movie_of_screen_id DESC limit 1";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([
                    ':movie_id'=>$_SESSION['movie_id']
                ]);
            $movieOfScreen_data = $stmt->fetch(PDO::FETCH_ASSOC);

            $sql = "INSERT INTO t_booking_details (r_movie_of_screen_id,r_payment_id,seat_details,seat_class,seat_number,total_seats)
            VALUES (:r_movie_of_screen_id,:r_payment_id,:seat_details,:seat_class,:seat_number,:total_seats)";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([
                    ':r_movie_of_screen_id'=> $movieOfScreen_data['movie_of_screen_id'],
                    ':r_payment_id' => $payments_data['payment_id'],
                    ':seat_details' => 'Accc',
                    ':seat_class' => $_SESSION['class'],
                    ':seat_number' => $_SESSION['seat_no'],
                    ':total_seats' => $_SESSION['count']
            ]);

            $sql = "SELECT * FROM t_booking_details ORDER BY booking_id DESC limit 1";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute();
            $bookings_data = $stmt->fetch(PDO::FETCH_ASSOC);
            return $bookings_data;
        } catch(Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
    public static function ticket_details(){
        try{
            $sql = "SELECT t_payments.*,t_booking_details.*,t_theatres.theatre_name, t_screens.screen_name,t_shows.show_name,t_movies.name
                    FROM t_payments 
                    INNER JOIN t_booking_details
                    ON t_booking_details.r_payment_id = t_payments.payment_id
                    INNER JOIN t_movie_of_screens
                    ON t_booking_details.r_movie_of_screen_id = t_movie_of_screens.movie_of_screen_id
                    INNER JOIN t_theatres
                    ON t_theatres.theatre_id = t_movie_of_screens.r_theatre_id
                    INNER JOIN t_screens
                    ON t_screens.screen_id = t_movie_of_screens.r_screen_id
                    INNER JOIN t_shows
                    ON t_shows.show_id = t_movie_of_screens.r_show_id
                    INNER JOIN t_movies
                    ON t_movies.movie_id = t_movie_of_screens.r_movie_id
                    WHERE t_payments.r_user_id = :r_user_id
                    ORDER BY t_payments.payment_id DESC";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([
                ':r_user_id'=>$_SESSION['CurrentUserData']['user_id']
            ]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            return $data;
        }catch(Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}