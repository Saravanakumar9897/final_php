<?php
/**
 * @Author:Banupriya
 * @Description:This RoleController will show the available roles.
 * Date: 24/10/19
 * Time: 1:03 AM
 */

namespace Controllers;


use Models\Role;
use Request\Request;
use Throwable;

class RoleController
{
  //This constructor function  will check wheather the user is superAdmin.  
    public function __construct()
    {
        auth('SuperAdmin');
    }

    //This roleIndex function will show the available roles in theatre
    public function roleIndex(){
        try {
          //This roles will contain the model and all available roles using the all().
            $roles = Role::all();
            //Then the fetched roles are displayed in view page through export function
            export('backend/roles/view_all',$roles->objects);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This roleForm function will fetch the form from the roles folder and display it in the view page
    public function roleForm(){
        try {
            export('backend/roles/create_form','');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

     //This roleStore function will check the Request method first,then get values as $request and the values are stored $formData then this roles are inserted into datebase,then redirected to roleIndex page
    public function roleStore(Request $request){
       try {
           $formData = $request->getBody();
           Role::insert($formData);
           redirect('/roleIndex');
       } catch (Throwable $e) {
           throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    //This roleShow function will check the Request method first,then it shows the values from the stored variable in view page
    public function roleShow(Request $request){
        try {
            $formData = $request->getBody();
            $role = Role::find($formData['role_id']);
            export('backend/roles/show',$role);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This roleEditForm function will fetch the existing values from the roles folder and display it in the edit form
    public function roleEditForm(Request $request){
        try {
            $formData = $request->getBody();
            $role = Role::find($formData['role_id']);
            export('backend/roles/edit_form',$role);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

     //This roleUpdate function will check the Request method first,then get values as $request and the values are stored $formData then this roles are updated into datebase,then redirected to roleIndex page
    public function roleUpdate(Request $request){
       try {
           $formData = $request->getBody();
           Role::update($formData);
           redirect('/roleIndex');
       } catch (Throwable $e) {
           throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    //This roleDelete function will check the Request method first,then get values as $request and the particular values are stored $formData then this roles are deleted into database,then redirected to roleIndex page
    public function roleDelete(Request $request){
        try {
            $formData = $request->getBody();
            Role::findDelete($formData['role_id']);
            redirect('/roleIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}