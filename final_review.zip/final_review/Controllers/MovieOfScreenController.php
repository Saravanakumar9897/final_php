<?php
/**
 * @Author:Banupriya
 * @Description:This MovieOfScreenController will show the available movies running in theatre. 
 * Date: 7/11/19
 * Time: 4:54 PM
 */

namespace Controllers;


use Models\Movie;
use Models\MovieOfScreen;
use Models\Screen;
use Models\Show;
use Models\Theatre;
use Request\Request;
use Throwable;

class MovieOfScreenController
{
    //This constructor function  will check wheather the user is superAdmin or Admin
    public function __construct()
    {
        auth(['SuperAdmin','Admin']);
    }

    //This index function will movieOfScreens the available movies in theatre
    public function index()
    {
        //This movies will contain the model and all available movies using the all().
        $movieOfScreens = MovieOfScreen::allWithRelation();
        //Then the fetched movies are displayed in view page through export function
        export('backend/movie_of_screen/view_all',$movieOfScreens->objects);
    }

     //This create function will fetch the form from the movie_of_screen folder and display it in the view page
    public function create(Request $request)
    {
        $theatres = Theatre::all();
        $screens = Screen::all();
        $shows = Show::all();
        $movies = Movie::all();
        export('backend/movie_of_screen/create_form',[$theatres->objects,$screens->objects,$shows->objects,$movies->objects]);
    }

    //This store function will check the Request method first,then get values as $request and the values are stored $formData then this movieofscreen are inserted into datebase,then redirected to movieOfScreenIndex page
    public function store(Request $request){
        $formData = $request->getBody();
        MovieOfScreen::insert($formData);
        redirect('/movieOfScreenIndex');
    }

    //This show function will check the Request method first,then it shows the values from the stored variable in view page
    public function show(Request $request){
        try {
            $formData = $request->getBody();
            $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
            export('backend/movie_of_screen/show',$movieOfScreen);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This edit function will fetch the existing values from the movie_of_screen folder and display it in the edit form
    public function edit(Request $request){
        $formData = $request->getBody();
        $theatres = Theatre::all();
        $shows = Show::all();
        $movies = Movie::all();
        $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
        $screens = Screen::multSelect([' * '],['r_theatre_id'=>$movieOfScreen->r_theatre_id]);
        export('backend/movie_of_screen/edit_form',[$theatres->objects,$screens,$shows->objects,$movies->objects,$movieOfScreen]);
    }

    public function update(Request $request){
        $formData = $request->getBody();
        MovieOfScreen::update($formData);
        redirect('/movieOfScreenIndex');
    }

    public function delete(Request $request){
        $formData = $request->getBody();
        MovieOfScreen::findDelete($formData['movie_of_screen_id']);
        redirect('/movieOfScreenIndex');
    }

}
?>