<?php
/**
 * @Author:Banupriya
 * @created_at:7.11.2019
 * @Description:This ShowController will show the available movies running in theatre. 
 */

namespace Controllers;


use Models\Show;
use Request\Request;
use Throwable;

class ShowController
{
    //This constructor function  will check wheather the user is superAdmin or Admin
    public function __construct()
    {
        auth(['SuperAdmin','Admin']);
    }

    //This showIndex function will show the available shows in theatre
    public function showIndex(){
        try {
            //This shows will contain the model and all available shows using the all().
            $shows = Show::all();
            //Then the fetched shows are displayed in view page through export function
            export('backend/shows/view_all',$shows->objects);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showForm function will fetch the form from the shows folder and display it in the view page
    public function showForm(){
        try {
            export('backend/shows/create_form','');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showStore function will check the Request method first,then get values as $request and the values are stored $formData then this shows are inserted into datebase,then redirected to showIndex page
    public function showStore(Request $request){
        try {
            $formData = $request->getBody();
            Show::insert($formData);
            redirect('/showIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showShow function will check the Request method first,then it shows the values from the stored variable in view page
    public function showShow(Request $request){
        try {
            $formData = $request->getBody();
            $show = Show::find($formData['show_id']);
            export('backend/shows/show',$show);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showEditForm function will fetch the existing values from the shows folder and display it in the edit form
    public function showEditForm(Request $request){
        try {
            $formData = $request->getBody();
            $show = Show::find($formData['show_id']);
            export('backend/shows/edit_form',$show);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showUpdate function will check the Request method first,then get values as $request and the values are stored $formData then this shows are updated into datebase,then redirected to showIndex page
    public function showUpdate(Request $request){
        try {
            $formData = $request->getBody();
            Show::update($formData);
            redirect('/showIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This showDelete function will check the Request method first,then get values as $request and the particular values are stored $formData then this shows are deleted into database,then redirected to showIndex page
    public function showDelete(Request $request){
        try {
            $formData = $request->getBody();
            Show::findDelete($formData['show_id']);
            redirect('/showIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
?>