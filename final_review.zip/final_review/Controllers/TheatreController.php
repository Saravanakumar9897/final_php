<?php
/**
 * Created by PhpStorm.
 * Theatre: Vishnu
 * Date: 31/10/19
 * Time: 3:38 AM
 */

// This following line is used to including the autoloader functions
namespace Controllers;

// Following functions are including Theatre,User,Request models
use Models\Theatre;
use Models\User;
use Request\Request;
// Following line is including the Throwable function.This is used to generating the error and error occured line
use Throwable;

// Theatre controller(The theatre function is called that routed from the router to this controller)
class TheatreController
{
    // This is the constructor to check the admin authendication
    public function __construct()
    {
        // This checking for the user is admin or super admin.This function is restrict the user to access the end user
        auth(['SuperAdmin','Admin']);
    }

    // This is the function to view theatre index function
    public function theatreIndex(){
        try {
            // call the Theatre model and the output of the Theatre model is stored in the variable $theatres
            $theatres = Theatre::all();
            // Following line is including the theatre index page and sending the $theatres variable to the view page using export method
            export('backend/theatres/view_all',$theatres->objects);
        } 
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to view theatre create form function
    public function theatreForm(){
        try {
            // call the user model and the output of the User model is stored in the variable $users
            $users = User::all();
            // Following line is including the theatre create page and sending the $users variable to the theatre edit page
            export('backend/theatres/create_form',$users->objects);
        }       
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to update theatre details form function
    public function theatreStore(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the Theatre model and the insert the theatre edit form data of the previous function is stored to use the below function calling
            Theatre::insert($formData);
            // This below line is redirected to the theatre index function
            redirect('/theatreIndex');
        }       
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to show the theatre show page in view file function
    public function theatreShow(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the Theatre model and the find the theatre required id data
            $theatre = Theatre::find($formData['theatre_id']);
            // This below line to including the theatre show page and sending the data of the $theatre using export
            export('backend/theatres/show',$theatre);
        }        
        // This line is throw the error if any error occured
        catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the theatre edit form page in view file function
    public function theatreEditForm(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the Theatre model and the find the theatre required id data
            $theatre = Theatre::find($formData['theatre_id']);
            // call the function find in the User model and the all function to fetching the data of the all theatre
            $users = User::all();
            // This below line to including the theatre edit page and sending the data of the $theatre using export
            export('backend/theatres/edit_form',[$theatre,$users->objects]);
        }        
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the theatre update the details sent by post method in the database
    public function theatreUpdate(Request $request){
        try {            
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the function update in Theatre model and that model update $formData
            Theatre::update($formData);
            // This below line is redirected to the theatre index function
            redirect('/theatreIndex');
        }        
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the theatre delete the details sent by post method in the database
    public function theatreDelete(Request $request){
        try {            
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function findDelete in the Theatre model and that model delete $formData
            Theatre::findDelete($formData['theatre_id']);
            // This below line is redirected to the theatre index function
            redirect('/theatreIndex');
        }         
        // This line is throw the error if any error occured
        catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}