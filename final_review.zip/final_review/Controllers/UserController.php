<?php

// This following line is used to including the autoloader functions
namespace Controllers;

// Following functions are including Role,User,Request models
use Models\Role;
use Models\User;
use Request\Request;
// Following line is including the Throwable function.This is used to generating the error and error occured line
use Throwable;

// Theatre controller(The theatre function is called that routed from the router to this controller)
class UserController
{
    // This is the constructor to check the admin authendication
    public function __construct() {
        // This checking for the user is admin or super admin.This function is restrict the user to access the end user
        auth(['SuperAdmin','Admin']);
    }

    // This is the function to view User index function
    public function userIndex(){
        try {
            // call the User model and the output of the User model is stored in the variable $users
            $users = User::all();
            // Following line is including the user index page and sending the $users variable to the view page using export method
            export('backend/users/view_all',$users->objects);
        } 
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to view create edit form function
    public function userForm(){
        try {
            // call the role model and the output of the Role model is stored in the variable $roles
            $roles = Role::all();
            // Following line is including the user create page and sending the $roles variable to the user edit page
            export('backend/users/create_form',$roles->objects);
        }       
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to userstore user insert function
    public function userStore(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // This below line checking the email is already is exists
            $formData['email_verified_at'] = NULL;
            // call the User model and the insert the user data of the previous function is stored to use the below function calling
            User::insert($formData);
            // This below line is redirected to the user index function
            redirect('/userIndex');
        }        
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to show the user show page in view file function
    public function userShow(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the User model and the find the user required id data
            $user = User::find($formData['user_id']);
            // This below line to including the user show page and sending the data of the $users using export
            export('backend/users/show',$user);
        }         
        // This line is throw the error if any error occured
        catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the theatre edit form page in view file function
    public function userEditForm(Request $request){
        try {
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the User model and the find the user required id data
            $user = User::find($formData['user_id']);
            // call the function find in the Role model and the all function to fetching the data of the all role
            $roles = Role::all(); 
            // This below line to including the user edit page and sending the data of the $users using export 
            export('backend/users/edit_form',[$user,$roles->objects]);
        }      
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the user update the details sent by post method in the database
    public function userUpdate(Request $request){
        try {           
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function find in the function update in User model and that model update $formData
            User::update($formData);
            // This below line is redirected to the user index function
            redirect('/userIndex');
        }       
        // This line is throw the error if any error occured
        catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    // This is the function to the user delete the details sent by post method in the database
    public function userDelete(Request $request){
        try {          
            // call the getbody function and the output of the getbody function is stored in the variable $formData(in the form of post or get variables)
            $formData = $request->getBody();
            // call the function findDelete in the User model and that model delete $formData
            User::findDelete($formData['user_id']);
            // This below line is redirected to the user index function
            redirect('/userIndex');
        }       
        // This line is throw the error if any error occured
        catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}